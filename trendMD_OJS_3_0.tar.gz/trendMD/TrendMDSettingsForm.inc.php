<?php

/**
 * @file plugins/generic/trendMD/TrendMDSettingsForm.inc.php
 *
 * Copyright (c) 2017 TrendMD Inc.
 * Distributed under the GNU GPL v2. For full terms see the file docs/COPYING.
 *
 * @class TrendMDSettingsForm
 * @ingroup plugins_generic_trendMD
 *
 * @brief Form for journal managers to modify TrendMD plugin settings
 */

import('lib.pkp.classes.form.Form');

class TrendMDSettingsForm extends Form {

	/** @var int */
	var $_journalId;

	/** @var object */
	var $_plugin;

	/**
	 * Constructor
	 * @param $plugin TrendMDPlugin
	 * @param $journalId int
	 */
	function __construct($plugin, $journalId) {
		$this->_journalId = $journalId;
		$this->_plugin = $plugin;

		parent::__construct($plugin->getTemplatePath() . 'settingsForm.tpl');

		$this->addCheck(new FormValidator($this, 'trendMDCode', 'required', 'plugins.generic.trendMD.manager.settings.trendMDCodeRequired'));

		$this->addCheck(new FormValidatorPost($this));
		$this->addCheck(new FormValidatorCSRF($this));
	}

	/**
	 * Initialize form data.
	 * @copydoc Form::initData()
	 */
	function initData() {
		$this->_data = array(
			'trendMDCode' => $this->_plugin->getSetting($this->_journalId, 'trendMDCode'),
		);
	}

	/**
	 * Assign form data to user-submitted data.
	 * @copydoc Form::readInputData()
	 */
	function readInputData() {
		$this->readUserVars(array('trendMDCode'));
	}

	/**
	 * Fetch the form.
	 * @copydoc Form::fetch()
	 */

	 function fetch($request) {
		$templateMgr = TemplateManager::getManager($request);
		$templateMgr->assign('pluginName', $this->_plugin->getName());
		return parent::fetch($request);
	}

	/**
	 * Save settings.
	 * @copydoc Form::execute()
	 */
	function execute() {
		$this->_plugin->updateSetting($this->_journalId, 'trendMDCode', trim($this->getData('trendMDCode'), "\"\';"), 'string');
	}
}

?>
